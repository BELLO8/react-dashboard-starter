import React from 'react';

export const Home = () => {
    return (
        <div className="">
            <div className="">
                <h1 className="text-2xl font-bold text-[#04356B]">
                    Tableau de bord
                </h1>
            </div>
        </div>
    )
}
